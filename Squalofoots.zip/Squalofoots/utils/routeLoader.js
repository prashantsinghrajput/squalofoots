const fs = require('fs');
const path = require('path');

/**
 * Dynamically load and register all routes from a directory.
 * @param {string} dir - Directory path containing route files.
 * @param {Express.Application} app - Express application instance.
 * @param {string} basePath - Base path for the routes (e.g., `/api` or `/`).
 */
const loadRoutes = (dir, app, basePath = '') => {
  fs.readdirSync(dir).forEach((file) => {
    const fullPath = path.join(dir, file);

    // Only process JavaScript files
    if (fs.lstatSync(fullPath).isFile() && file.endsWith('.js')) {
      const route = require(fullPath);
      const routePath = `${basePath}/${file.replace('.js', '')}`;
      app.use(routePath === `${basePath}/index` ? basePath : routePath, route);
    }
  });
};

module.exports = loadRoutes;
