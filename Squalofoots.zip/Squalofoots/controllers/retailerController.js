const Retailer = require('../models/Retailer');


// Get a retailer's ledger
exports.getLedger = async (req, res) => {
  const { id } = req.params; // Retailer ID
  const page = parseInt(req.query.page) || 1; // Current page (default: 1)
  const limit = parseInt(req.query.limit) || 20; // Records per page (default: 20)

  try {
    const retailer = await Retailer.findById(id);
    if (!retailer) {
      return res.status(404).json({ success: false, message: 'Retailer not found.' });
    }

    const totalRecords = retailer.purchases.length; // Total number of transactions
    const totalPages = Math.ceil(totalRecords / limit); // Total pages based on limit
    const startIndex = (page - 1) * limit; // Start index for the current page
    const endIndex = startIndex + limit; // End index for the current page

    // Paginated data
    const paginatedLedger = retailer.purchases.slice(startIndex, endIndex).map((p, index) => {
      const runningBalance = retailer.purchases.slice(0, startIndex + index + 1).reduce((balance, txn) => {
        return txn.type === 'credit' ? balance - txn.amount : balance + txn.amount;
      }, 0);

      return {
        date: p.date,
        particulars: p.description,
        credit: p.type === 'credit' ? p.amount : null,
        debit: p.type === 'debit' ? p.amount : null,
        balance: runningBalance,
      };
    });

    res.json({
      success: true,
      name: retailer.name,
      totals: {
        totalInvoices: retailer.purchases.reduce((sum, txn) => txn.type === 'debit' ? sum + txn.amount : sum, 0),
        totalReceived: retailer.purchases.reduce((sum, txn) => txn.type === 'credit' ? sum + txn.amount : sum, 0),
        totalPending: retailer.balance,
        totalStockSold: retailer.purchases.reduce((sum, txn) => txn.type === 'debit' ? sum + txn.amount : sum, 0),
      },
      ledger: paginatedLedger,
      pagination: {
        currentPage: page,
        totalPages,
        totalRecords,
        limit,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
};


// Add a transaction for a retailer
exports.addTransaction = async (req, res) => {
  const { id } = req.params; // Retailer ID
  const { description, amount, type, mode } = req.body;

  // Validate required fields
  if (!description || !amount || !type) {
    return res.status(400).json({ success: false, message: 'Missing required fields.' });
  }

  try {
    // Find the retailer
    const retailer = await Retailer.findById(id);
    if (!retailer) {
      return res.status(404).json({ success: false, message: 'Retailer not found.' });
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount)) {
      return res.status(400).json({ success: false, message: 'Invalid amount.' });
    }

    // Calculate new balance incrementally
    const previousBalance = retailer.balance || 0;
    const newBalance = type === 'received'
      ? previousBalance - parsedAmount // Subtract for payments received
      : previousBalance + parsedAmount; // Add for stock supplied

    console.log("Previous Balance:", previousBalance);
    console.log("Calculated Balance:", newBalance);

    // Create the transaction
    const newTransaction = {
      retailerId: id,
      description,
      amount: parsedAmount,
      type: type === 'received' ? 'credit' : 'debit',
      mode: mode || null,
      date: new Date(),
    };

    // Add the transaction to purchases and update the balance
    retailer.purchases.push(newTransaction);
    retailer.balance = newBalance; // Only store balance in the retailer model

    await retailer.save();

    res.json({
      success: true,
      message: 'Transaction added successfully.',
      transaction: newTransaction,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
};



// Get all retailers
exports.getAllRetailers = async (req, res) => {
  try {
    const retailers = await Retailer.find({});
    res.status(200).json({ success: true, retailers });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Delete a retailer
exports.deleteRetailer = async (req, res) => {
  try {
    const { id } = req.params;
    const retailer = await Retailer.findByIdAndDelete(id);
    if (!retailer) {
      return res.status(404).json({ success: false, message: 'Retailer not found' });
    }
    res.status(200).json({ success: true, message: 'Retailer deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Update retailer details
exports.updateRetailer = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, contact } = req.body;

    const retailer = await Retailer.findByIdAndUpdate(id, { name, contact }, { new: true });
    if (!retailer) {
      return res.status(404).json({ success: false, message: 'Retailer not found' });
    }

    res.status(200).json({ success: true, message: 'Retailer updated successfully', retailer });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
