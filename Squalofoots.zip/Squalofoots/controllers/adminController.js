const Retailer = require('../models/Retailer');
const Vendor = require('../models/vendor')


// Add a new retailer
exports.addRetailer = async (req, res) => {
  try {
    const { name, contact } = req.body;
    const newRetailer = new Retailer({ name, contact });
    await newRetailer.save();
    res.status(201).json({ success: true, message: 'Retailer added successfully', retailer: newRetailer });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Add a transaction (purchase or payment)
exports.addTransaction = async (req, res) => {
  try {
    const { retailerId, description, amount, type } = req.body;
    const retailer = await Retailer.findById(retailerId);
    if (!retailer) return res.status(404).json({ success: false, message: 'Retailer not found' });

    // Update transactions and balance
    retailer.purchases.push({ description, amount, type });
    retailer.balance += type === 'credit' ? amount : -amount;
    await retailer.save();

    res.status(200).json({ success: true, message: 'Transaction added successfully', retailer });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get all retailers
exports.getAllRetailers = async (req, res) => {
  try {
    const retailers = await Retailer.find({});
    res.status(200).json({ success: true, retailers });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get a specific retailer by ID
exports.getRetailerById = async (req, res) => {
  try {
    const retailer = await Retailer.findById(req.params.id);
    if (!retailer) return res.status(404).json({ success: false, message: 'Retailer not found' });

    res.status(200).json({ success: true, retailer });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Delete a retailer
exports.deleteRetailer = async (req, res) => {
  try {
    const retailer = await Retailer.findByIdAndDelete(req.params.id);
    if (!retailer) return res.status(404).json({ success: false, message: 'Retailer not found' });

    res.status(200).json({ success: true, message: 'Retailer deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Update retailer details
exports.updateRetailer = async (req, res) => {
  try {
    const { name, contact } = req.body;
    const retailer = await Retailer.findByIdAndUpdate(req.params.id, { name, contact }, { new: true });
    if (!retailer) return res.status(404).json({ success: false, message: 'Retailer not found' });

    res.status(200).json({ success: true, message: 'Retailer updated successfully', retailer });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getStats = async (req, res) => {
  try {
    const retailers = await Retailer.find(); // Fetch all retailers
    const totalRetailers = retailers.length;

    let totalStockSold = 0;
    let totalAmountReceived = 0;
    let totalAmountPending = 0;

    retailers.forEach((retailer) => {
      retailer.purchases.forEach((txn) => {
        if (txn.type === 'debit') {
          totalStockSold += txn.amount;
        } else if (txn.type === 'credit') {
          totalAmountReceived += txn.amount;
        }
      });
      totalAmountPending += retailer.balance; // Accumulate pending balances
    });

    res.json({
      success: true,
      totalStockSold,
      totalAmountReceived,
      totalAmountPending,
      totalRetailers,
    });
  } catch (err) {
    console.error('Error fetching stats:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch stats.' });
  }
};

exports.getDashboardData = async (req, res) => {
  try {
    const retailers = await Retailer.find();
    const vendors = await Vendor.find();

    const totalRetailers = retailers.length;
    const totalVendors = vendors.length;

    let totalStockSold = 0;
    let totalAmountReceived = 0;

    const topRetailers = retailers
      .sort((a, b) => b.balance - a.balance) // Sort by balance (highest first)
      .slice(0, 5);

     const topVendors = vendors
       .sort((a, b) => b.balance - a.balance) // Sort by balance (highest first)
       .slice(0, 5);

    retailers.forEach((retailer) => {
      retailer.purchases.forEach((txn) => {
        if (txn.type === 'debit') {
          totalStockSold += txn.amount;
        } else if (txn.type === 'credit') {
          totalAmountReceived += txn.amount;
        }
      });
    });

    res.json({
      success: true,
      totalRetailers,
      totalVendors,
      totalStockSold,
      totalAmountReceived,
      topRetailers,
      topVendors,
    });
  } catch (err) {
    console.error('Error fetching dashboard data:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch dashboard data.' });
  }
};
