const Vendor = require('../models/vendor');

// Fetch all vendors
exports.listVendors = async (req, res) => {
  try {
    const vendors = await Vendor.find().sort({ name: 1 }); // Sort alphabetically
    res.json({ success: true, vendors });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch vendors', error: err.message });
  }
};

// Add a new vendor
exports.addVendor = async (req, res) => {
  const { name, contact } = req.body;

  // Validate input
  if (!name || !contact) {
    return res.status(400).json({ success: false, message: 'Name and contact are required' });
  }

  try {
    const newVendor = new Vendor({ name, contact });
    await newVendor.save();
    res.json({ success: true, message: 'Vendor added successfully', vendor: newVendor });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to add vendor', error: err.message });
  }
};

// Delete a vendor by ID
exports.deleteVendor = async (req, res) => {
  const { id } = req.params;

  try {
    const vendor = await Vendor.findByIdAndDelete(id);
    if (!vendor) {
      return res.status(404).json({ success: false, message: 'Vendor not found' });
    }
    res.json({ success: true, message: 'Vendor deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete vendor', error: err.message });
  }
};

// View vendor ledger by ID
// View vendor ledger by ID
exports.viewLedger = async (req, res) => {
  const { id } = req.params;

  try {
    const vendor = await Vendor.findById(id);
    if (!vendor) {
      return res.status(404).json({ success: false, message: 'Vendor not found' });
    }

    // Calculate totals
    const thisMonth = new Date();
    const startOfMonth = new Date(thisMonth.getFullYear(), thisMonth.getMonth(), 1);

    const purchasesThisMonth = vendor.purchases.filter((p) => new Date(p.date) >= startOfMonth);
    const totalInvoices = purchasesThisMonth
      .filter((p) => p.type === 'debit')
      .reduce((sum, p) => sum + p.amount, 0);

    const totalPayments = purchasesThisMonth
      .filter((p) => p.type === 'credit')
      .reduce((sum, p) => sum + p.amount, 0);

    const totalPending = vendor.balance;
    const totalStockOrdered = vendor.purchases
      .filter((p) => p.type === 'debit')
      .reduce((sum, p) => sum + p.amount, 0);

    // Return vendor ledger details
    res.json({
      success: true,
      vendor: {
        name: vendor.name,
        contact: vendor.contact,
        balance: vendor.balance,
        purchases: vendor.purchases,
      },
      totals: {
        totalInvoices,
        totalPayments,
        totalPending,
        totalStockOrdered,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch vendor ledger', error: err.message });
  }
};


// Add a transaction to vendor ledger
exports.addTransaction = async (req, res) => {
  const { id } = req.params;
  const { description, amount, type, mode } = req.body;

  if (!description || !amount || !type) {
    return res.status(400).json({ success: false, message: 'Missing required fields.' });
  }

  try {
    const vendor = await Vendor.findById(id);
    if (!vendor) {
      return res.status(404).json({ success: false, message: 'Vendor not found.' });
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount)) {
      return res.status(400).json({ success: false, message: 'Invalid amount.' });
    }

    const newBalance =
      type === 'invoice' ? vendor.balance + parsedAmount : vendor.balance - parsedAmount;

    const newTransaction = {
      description,
      amount: parsedAmount,
      type: type === 'invoice' ? 'debit' : 'credit',
      mode: mode || null,
      balance: newBalance,
      date: new Date(),
    };

    vendor.purchases.push(newTransaction);
    vendor.balance = newBalance;

    await vendor.save();

    res.json({ success: true, message: 'Transaction added successfully.', transaction: newTransaction });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getVendorStats = async (req, res) => {
  try {
    const vendors = await Vendor.find();

    // Calculate stats
    const totalVendors = vendors.length;
    const totalStockPurchased = vendors.reduce((sum, vendor) => sum + vendor.purchases.reduce((acc, purchase) => acc + (purchase.type === 'debit' ? purchase.amount : 0), 0), 0);
    const totalAmountPaid = vendors.reduce((sum, vendor) => sum + vendor.purchases.reduce((acc, purchase) => acc + (purchase.type === 'credit' ? purchase.amount : 0), 0), 0);
    const totalAmountPending = totalStockPurchased - totalAmountPaid;

    res.json({
      success: true,
      stats: {
        totalVendors,
        totalStockPurchased,
        totalAmountPaid,
        totalAmountPending,
      },
      vendors,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch vendor stats', error: err.message });
  }
};