const express = require('express');
const router = express.Router();
const vendorController = require('../../controllers/vendorController');

// API Endpoints
router.get('/list', vendorController.listVendors); // Fetch all vendors
router.post('/add', vendorController.addVendor);   // Add a new vendor
router.delete('/delete/:id', vendorController.deleteVendor); // Delete a vendor by ID
router.get('/ledger/:id', vendorController.viewLedger); // View vendor ledger by ID
router.post('/ledger/:id/add-transaction', vendorController.addTransaction); // Add a transaction to vendor ledger
router.get('/stats', vendorController.getVendorStats); // Fetch vendor stats

module.exports = router;
