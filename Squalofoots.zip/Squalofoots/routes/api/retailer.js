const express = require('express');
const router = express.Router();
const retailerController = require('../../controllers/retailerController'); // Ensure this path is correct

// Example problematic route
router.get('/ledger/:id', retailerController.getLedger);
router.post('/ledger/:id/add-transaction', retailerController.addTransaction);

module.exports = router;
