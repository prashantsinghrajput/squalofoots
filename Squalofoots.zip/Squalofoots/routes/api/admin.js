const express = require('express');
const router = express.Router();
const adminController = require('../../controllers/adminController');

// Add a retailer
router.post('/add-retailer', adminController.addRetailer);

// Add a transaction
router.post('/add-transaction', adminController.addTransaction);

router.get('/dashboard', adminController.getDashboardData);

// Get all retailers
router.get('/retailers', adminController.getAllRetailers);
router.get('/stats', adminController.getStats);
//router.get('/dashboard-stats', adminController.getDashboardStats);
module.exports = router;
