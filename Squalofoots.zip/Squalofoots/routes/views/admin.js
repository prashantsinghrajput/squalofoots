const express = require('express');
const router = express.Router();


// Add Retailer Form
router.get('/add-retailer', (req, res) => {
  res.render('admin/add-retailer', { title: 'Retailer Management' });
});


router.get('/ledger/:id', (req, res) => {
  const clientId = req.params.id;
  res.render('admin/client-ledger', { title: 'Ledger', clientId });
});


router.get('/add-vendors', (req, res) => {
  res.render('vendor/add-vendor', { title: 'Vendor Management' });
});

router.get('/ledger/vendor/:id', (req, res) => {
  const clientId = req.params.id;
  res.render('vendor/vendor-ledger', { title: 'Ledger', clientId });
});

module.exports = router;
