const mongoose = require('mongoose');

// Define the Retailer schema
const RetailerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  contact: {
    type: String,
    required: true,
  },
  balance: {
    type: Number,
    default: 0, // Starting balance
  },
  purchases: [
    {
      date: {
        type: Date,
        default: Date.now, // Automatically set to current date
      },
      description: {
        type: String,
      },
      amount: {
        type: Number,
        required: true,
      },
      type: {
        type: String,
        enum: ['credit', 'debit'], // credit = payment, debit = purchase
        required: true,
      },
    },
  ],
});

// Create the Retailer model
const Retailer = mongoose.model('Retailer', RetailerSchema);

module.exports = Retailer;