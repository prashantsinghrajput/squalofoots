const mongoose = require('mongoose');

// Define the Vendor schema
const VendorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  contact: {
    type: String,
    required: true,
  },
  balance: {
    type: Number,
    default: 0,
  },
  purchases: [
    {
      date: {
        type: Date,
        default: Date.now,
      },
      description: {
        type: String,
      },
      amount: {
        type: Number,
        required: true,
      },
      type: {
        type: String,
        enum: ['credit', 'debit'], // credit = payment, debit = invoice received
        required: true,
      },
      mode: {
        type: String, // Optional: Mode of payment for credits
      },
      balance: {
        type: Number,
        required: true,
      },
    },
  ],
});

const Vendor = mongoose.model('Vendor', VendorSchema);

module.exports = Vendor;
