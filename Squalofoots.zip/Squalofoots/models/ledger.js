const mongoose = require('mongoose');

// Define the Ledger schema
const LedgerSchema = new mongoose.Schema({
  entityId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    refPath: 'entityType', // Dynamic reference based on entityType
  },
  entityType: {
    type: String,
    required: true,
    enum: ['Retailer', 'Vendor'], // Determines the reference model
  },
  date: {
    type: Date,
    default: Date.now,
  },
  description: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  type: {
    type: String,
    enum: ['credit', 'debit'], // credit = payment received/made, debit = stock supplied/purchased
    required: true,
  },
  mode: {
    type: String, // Mode of payment (optional)
  },
});

// Create the Ledger model
const Ledger = mongoose.model('Ledger', LedgerSchema);

module.exports = Ledger;
