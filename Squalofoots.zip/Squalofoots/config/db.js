const mongoose = require('mongoose');

// Database connection function
const connectDB = async () => {
  try {
    // Replace the connection string with your MongoDB URL
    const dbURI = 'mongodb+srv://squalo:squalofoots@cluster0.1hhcz.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

    await mongoose.connect(dbURI, {
     // useNewUrlParser: true,
     // useUnifiedTopology: true,
    });

    console.log('✅ Database connected successfully!');
  } catch (err) {
    console.error('❌ Database connection failed:', err.message);
    process.exit(1); // Exit process with failure
  }
};

module.exports = connectDB;